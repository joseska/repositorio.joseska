# resource.images.arctic.waves
